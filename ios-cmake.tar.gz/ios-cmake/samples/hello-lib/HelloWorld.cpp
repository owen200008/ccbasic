#include "HelloWorld.h"

string HelloWorld::helloWorld(){
	string s("Hello World");
	return s;
}
